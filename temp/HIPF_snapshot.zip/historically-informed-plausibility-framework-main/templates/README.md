# Templates (Non-Diegetic)

Copy-ready templates for creating new documents.

Templates are operational scaffolding and are not sources.
