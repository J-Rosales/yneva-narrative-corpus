<!-- DIEGETIC DOCUMENT TEMPLATE -->
# <Title>

## Metadata
- Document type: (oral tale / poem / decree / chronicle / letter / ...)
- Narrator / speaker:
- Culture / polity of origin:
- Intended audience:
- Approximate date / date range:
- Place of composition (if known):
- Transmission: (oral / copied / archived / rediscovered / ...)

## Text

