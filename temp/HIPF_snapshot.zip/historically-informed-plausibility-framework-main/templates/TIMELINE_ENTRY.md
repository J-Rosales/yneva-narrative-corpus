<!-- NON-DIEGETIC TEMPLATE -->
### <DATE>
**Region:** <...>
**Type:** <...>
**Summary:** <one or two sentences, neutral>
**Notes:** <optional; ambiguity, recognition, historiography>
**Narratives:**
- <corpus/...>
**Status:** <optional: disputed / regional / conventional>
