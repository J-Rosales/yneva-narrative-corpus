<!-- NON-DIEGETIC TEMPLATE -->
# Culture / Polity Reference: <Name>

## Identification
- Names / Endonyms / Exonyms:
- Polity type (if applicable):
- Primary ethnos/species:
- Timeframe (if bounded):
- Geographic scope:

## Social Structure

## Political Order
- Legitimacy bases:
- Succession norms:
- Elite composition:

## Law and Custom
- Formal law:
- Informal practice:
- Taboo constraints:

## Administration and Capacity
- Measurement and recordkeeping:
- Extraction (tax, labor):
- Enforcement reach:

## Military Organization

## Economy

## Naming Conventions
- Personal names:
- Offices/titles:
- Places:

## Religion and Belief Interfaces
- Belief regimes present (reference paths):
- Institutional interfaces:

## Notes and Internal Variation
