<!-- NON-DIEGETIC TEMPLATE -->
# Periodization Scheme: <Name>

## Scope
- Intended users:
- Region/culture coverage:
- Dating conventions:

## Major Periods
- <Name>: <range>

## Minor Periods
- <Name>: <range or null>

## Notes
- Contested boundaries:
- Alternate names:
